print "Hey Sengir\n"

path = Dir.pwd + "/"

Dir["assets/**/*.txt"].each{ |item|
  next if item == '.' or item == '..'
  frames = []
  maxFrame = 0;
  filePath = path + item
   File.open(filePath, 'r') {|f| 
        while (line = f.gets)
                if(line.include? "*")
                        frame = line.split("*")[0].strip
                        time =  line.split("*")[1].strip
                        maxFrame = [frame.to_i, maxFrame].max
                        frames.push([frame, time])
                end
        
end
maxFrame = maxFrame + 1
puts filePath.slice! ".txt"
  }
  File.open(filePath+".png.mcmeta", 'w+') {|f| 
        f.write("{") 
        f.write("\"animation\":{") 
        f.write("\"width\":1,") 
        f.write("\"height\":#{maxFrame},") 
        f.write("\"frametime\":1,") 
        f.write("\"frames\":[") 
        isFirst = true
        frames.each {|d| 
                frameString = ""
                if(!isFirst)
                        frameString.concat(",")
                end
                frameString.concat("{\"index\":#{d[0]},\"time\":#{d[1]}}")
                isFirst = false
                f.write(frameString);
        }
        f.write("]}}") 
  }
}